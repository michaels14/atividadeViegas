<?php

namespace App\Http\Controllers;


use Laravel\Lumen\Routing\Controller as BaseController;


class GamesController extends BaseController
{
    public function index(){
        $results = app('db')->select("SELECT * FROM games");
        dd($results);

    }
}
